package com.lagou.edu.dao;

import com.lagou.edu.entity.Resume;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

/**
 * @author cjs
 * @version 1.0.0
 * @className ResumeDao
 * @description TODO
 * @createTime 2020年05月19日 03:15:00
 */
public interface ResumeDao extends JpaRepository<Resume,Long>, JpaSpecificationExecutor<Resume> {

   public List<Resume> findByIdAndName(Long id,String name);
}

