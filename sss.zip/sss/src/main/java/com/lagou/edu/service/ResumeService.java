package com.lagou.edu.service;

import com.lagou.edu.entity.Resume;

import javax.xml.ws.ServiceMode;
import java.util.List;


/**
 * @author cjs
 * @version 1.0.0
 * @className ResumeDao
 * @description TODO
 * @createTime 2020年05月19日 03:15:00
 */
public interface ResumeService {

    /**
     * @author cjs
     * @description //获取所有记录
     * @date 2020/5/19 3:22
     * @param
     * @return java.util.List<com.lagou.edu.entity.Resume>
     **/
     List<Resume> findAll();

    /**
     * @author cjs
     * @description //获取指定id的记录
     * @date 2020/5/19 3:22
     * @param id
     * @return com.lagou.edu.entity.Resume
     **/
    Resume findById(Long id);

    /**
     * @author cjs
     * @description //根据id和name检索
     * @date 2020/5/19 3:22
     * @param id,name
     * @return java.util.List<com.lagou.edu.entity.Resume>
     **/
     List<Resume> findByIdAndName(Long id, String name);

    /**
     * @author cjs
     * @description //新增
     * @date 2020/5/19 3:23
     * @param resume
     * @return void
     **/
    void saveResume(Resume resume);

    /**
     * @author cjs
     * @description //修改
     * @date 2020/5/19 3:23
     * @param resume
     * @return void
     **/
    void updateResume(Resume resume);

    /**
     * @author cjs
     * @description //删除
     * @date 2020/5/19 3:23
     * @param id
     * @return void
     **/
    void deleteById(Long id);
}
