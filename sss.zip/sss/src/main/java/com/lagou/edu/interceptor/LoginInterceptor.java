package com.lagou.edu.interceptor;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author cjs
 * @version 1.0.0
 * @className LoginInterceptor
 * @description TODO
 * @createTime 2020年05月19日 03:50:00
 */
public class LoginInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
       String username=request.getParameter("username");
       String password=request.getParameter("password");
        if("admin".equals(username)&& "admin".equals(password)){
            return true;
        }
        response.sendRedirect("index.jsp?errMessage=no permisson!");
        return false;
    }

}
