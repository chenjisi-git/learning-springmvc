package com.lagou.edu.controller;

import com.lagou.edu.service.ResumeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 * @author cjs
 * @version 1.0.0
 * @className LoginController
 * @description TODO
 * @createTime 2020年05月19日 20:06:00
 */
@Controller
public class LoginController {

    @Autowired
    private ResumeService resumeService;

    /**
     * @title 登入
     * @description
     * @author cjs
     * @updateTime 2020/5/19 17:51
     * @param
     * @return org.springframework.web.servlet.ModelAndView
     */
    @PostMapping("/login")
    public ModelAndView login() throws Exception {
        ModelAndView view = new ModelAndView();
        view.addObject("list",resumeService.findAll());
        view.setViewName("/list.jsp");
        return view;
    }
}
