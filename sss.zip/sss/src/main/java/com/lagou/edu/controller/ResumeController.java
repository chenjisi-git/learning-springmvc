package com.lagou.edu.controller;

import com.lagou.edu.entity.Resume;
import com.lagou.edu.service.ResumeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequestMapping("/resume")
public class ResumeController {


    @Autowired
    private ResumeService resumeService;

    /**
     * @title 查询列表
     * @description
     * @author aleng
     * @updateTime 2020/5/19 17:51
     * @param
     * @return org.springframework.web.servlet.ModelAndView
     */
    @GetMapping("/list")
    public ModelAndView  queryAll() throws Exception {
        ModelAndView view = new ModelAndView();
        view.addObject("list",resumeService.findAll());
        view.setViewName("/list.jsp");
        return view;
    }

    /**
     * @title 保存或修改
     * @description
     * @author aleng
     * @updateTime 2020/5/19 17:51
     * @param
     * @return org.springframework.web.servlet.ModelAndView
     */
    @PostMapping("")
    public ModelAndView save(Resume resume) throws Exception {
        if (null==resume.getId()){
            resumeService.saveResume(resume);
        }else{
            resumeService.updateResume(resume);
        }
        ModelAndView view = new ModelAndView();
        view.addObject("list",resumeService.findAll());
        view.setViewName("/list.jsp");
        return view;
    }


    /**
     * @title 删除
     * @description
     * @author aleng
     * @updateTime 2020/5/19 17:51
     * @param
     * @return org.springframework.web.servlet.ModelAndView
     */
    @DeleteMapping("/{id}")
    public ModelAndView delete(@PathVariable(value = "id") Long id) throws Exception {
        resumeService.deleteById(id);
        ModelAndView mv = new ModelAndView("redirect:/resume/list");
        mv.addObject("list",resumeService.findAll());
        return mv;
    }

    /**
     * @title 添加和删除页面跳转
     * @description
     * @author aleng
     * @updateTime 2020/5/19 17:51
     * @param
     * @return org.springframework.web.servlet.ModelAndView
     */
    @GetMapping("/forward")
    public ModelAndView view(@RequestParam(value = "id",required = false) Long id) throws Exception {
        ModelAndView view = new ModelAndView();
        view.addObject("title","新增");
        view.addObject("resume",new Resume());
        if(null!=id){
            Resume resume=resumeService.findById(id);
            view.addObject("title","修改");
            view.addObject("id",id);
            view.addObject("resume",resume);
        }
        view.setViewName("/resume.jsp");
        return view;
    }

}
